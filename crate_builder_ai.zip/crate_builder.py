
import streamlit as st
import pandas as pd
from io import BytesIO
import base64
from PIL import Image, ImageDraw

# Title
st.title("📦 Crate Builder AI - Web Assistant")
st.markdown("Easily calculate crate size, material, and cut list for your item.")

# Sidebar inputs
st.sidebar.header("Object Details")
item_type = st.sidebar.selectbox("Item Type", ["Furniture", "Artwork", "Sculpture", "Electronics", "Machinery", "Other"])
length = st.sidebar.number_input("Length (cm)", min_value=1)
width = st.sidebar.number_input("Width (cm)", min_value=1)
height = st.sidebar.number_input("Height (cm)", min_value=1)
weight = st.sidebar.number_input("Weight (kg)", min_value=1)
fragility = st.sidebar.radio("Fragility Level", ["Low", "Medium", "High"])

st.sidebar.header("Shipping Details")
shipping_method = st.sidebar.selectbox("Shipping Method", ["Road", "Air", "Sea"])
material_pref = st.sidebar.selectbox("Crate Material Preference", ["Auto", "Wood", "Cardboard", "Hybrid"])

# Padding logic
def get_padding(material, fragility, shipping):
    if material == "Cardboard":
        return 15 if fragility == "High" else 10
    elif material == "Wood":
        if fragility == "High":
            return 12 if shipping in ["Air", "Sea"] else 10
        elif fragility == "Medium":
            return 8
        else:
            return 5
    elif material == "Hybrid":
        return 12 if fragility == "High" else 8
    return 10

padding = get_padding(material_pref, fragility, shipping_method)

# Crate dimensions
internal_length = length + 2 * padding
internal_width = width + 2 * padding
internal_height = height + 2 * padding

panel_thickness = 1.2 if material_pref != "Cardboard" else 0.8
external_length = internal_length + panel_thickness
external_width = internal_width + panel_thickness
external_height = internal_height + panel_thickness

# Crate type logic
if material_pref == "Auto":
    if weight > 80 or fragility == "High":
        crate_type = "Runner Base Crate (Wood)"
        material = "Wood"
    elif weight <= 80 and shipping_method == "Air":
        crate_type = "Pallet-Style Crate (Cardboard Hybrid)"
        material = "Hybrid"
    else:
        crate_type = "Standard Wood Crate"
        material = "Wood"
else:
    crate_type = f"{material_pref} Crate"
    material = material_pref

# Results
st.subheader("🔧 Crate Recommendation")
st.markdown(f"**Crate Type:** {crate_type}")
st.markdown(f"**Recommended Padding:** {padding} cm on all sides")

st.subheader("📐 Crate Dimensions")
st.markdown(f"**Internal (usable) size:** {internal_length:.1f} × {internal_width:.1f} × {internal_height:.1f} cm")
st.markdown(f"**External (overall) size:** {external_length:.1f} × {external_width:.1f} × {external_height:.1f} cm")

st.subheader("🪵 Material Guidance")
st.markdown(f"**Material:** {material}")
st.markdown("Choose plywood (12–18 mm), triple-wall cardboard, or timber battens depending on budget and shipping risk.")

st.subheader("📋 Suggested Next Steps")
st.markdown("- Generate cut list based on external dimensions\n- Add foam or internal lining based on fragility\n- Request a PDF or diagram if needed")

# --- Export Features ---
# Generate cut list dataframe
cut_data = {
    "Part": ["Base Panel", "Top Panel", "Side Panels (x2)", "End Panels (x2)"],
    "Length (cm)": [external_length, external_length, external_length, external_width],
    "Width (cm)": [external_width, external_width, external_height, external_height]
}
df_cutlist = pd.DataFrame(cut_data)

# Download CSV button
csv = df_cutlist.to_csv(index=False).encode('utf-8')
st.download_button("📥 Download Cut List (CSV)", csv, "cut_list.csv", "text/csv")

# --- Visual Guide ---
# Simple visual using Pillow
img = Image.new("RGB", (600, 400), "white")
draw = ImageDraw.Draw(img)
draw.rectangle([100, 100, 500, 300], outline="black", width=3)
draw.text((120, 110), "Top View", fill="black")
draw.text((120, 140), f"External: {external_length:.1f} x {external_width:.1f} cm", fill="black")
buffer = BytesIO()
img.save(buffer, format="PNG")
buffer.seek(0)
st.image(buffer, caption="Crate Top View Diagram")

# Download image button
b64 = base64.b64encode(buffer.getvalue()).decode()
href = f'<a href="data:file/png;base64,{b64}" download="crate_diagram.png">📥 Download Diagram (PNG)</a>'
st.markdown(href, unsafe_allow_html=True)
